# JanYatri — Editable Source Code Starter

This ZIP is a **reconstructed, editable starter project** for JanYatri based on the product details shared in the conversation. It is **not the original source code downloaded from** https://travel-bice-rho.vercel.app/; a deployed Vercel URL does not expose the original repository/project files.

## Included
- `public/index.html` — responsive trip planner interface
- `public/style.css` — styling
- `public/app.js` — frontend form, TinyFish request, and result rendering
- `server.js` — Express backend that keeps the TinyFish API key server-side
- `.env.example` — environment variable template
- `package.json` — Node dependencies and start script

## Run locally (Windows PowerShell)
1. Install Node.js 18 or newer.
2. Extract this ZIP and open PowerShell in this folder.
3. Run `npm install`.
4. Run `Copy-Item .env.example .env`.
5. Edit `.env` and set `TINYFISH_API_KEY=your_real_key_here`.
6. Run `npm start` and open http://localhost:3000.

Get a TinyFish key from https://agent.tinyfish.ai/api-keys. Never put the key in frontend JavaScript or commit `.env` to GitHub.

## Deploying
This starter uses an Express server. It can run on a Node host such as Render/Railway. To deploy on Vercel, convert the Express API to Vercel serverless functions and set `TINYFISH_API_KEY` in Project Settings → Environment Variables. Do not expose the key in public frontend code.

## Important
- The live URL was not sufficient to retrieve the exact original project files. To get an exact ZIP of the website's source, export/download the original project from its builder or GitHub repository and share it.
- TinyFish integration requires a valid API key and live testing. Results are research estimates, not ticket/hotel bookings or guaranteed availability.
