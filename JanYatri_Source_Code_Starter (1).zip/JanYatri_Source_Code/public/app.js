const form = document.querySelector("#trip-form");
const submitBtn = document.querySelector("#submit-btn");
const statusBox = document.querySelector("#status");
const resultsBox = document.querySelector("#results");

const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
form.elements.date.min = localDate;
form.elements.date.value = localDate;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[ch]);
}
function safeUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return ["https:", "http:"].includes(url.protocol) ? url.href : "";
  } catch { return ""; }
}
function money(value) {
  if (value === null || value === undefined || value === "") return "Not verified";
  const number = Number(value);
  return Number.isFinite(number) ? "₹" + number.toLocaleString("en-IN") : escapeHtml(value);
}
function link(url, label = "View source") {
  const href = safeUrl(url);
  return href ? `<a href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)} ↗</a>` : "";
}
function showStatus(message, type = "") {
  statusBox.className = `status ${type}`;
  statusBox.textContent = message;
}
function itemCard(item, kind) {
  if (!item || typeof item !== "object") return "";
  const name = item.name || item.mode || item.operator || "Option";
  let details = "";
  if (kind === "transport") {
    details = `<p>${escapeHtml(item.operator || item.mode || "Transport option")}${item.duration ? " · " + escapeHtml(item.duration) : ""}</p>
      <p class="amount">Estimated fare: ${money(item.estimated_fare_inr)}</p>
      ${item.departure_or_schedule ? `<p>${escapeHtml(item.departure_or_schedule)}</p>` : ""}
      ${item.notes ? `<p>${escapeHtml(item.notes)}</p>` : ""}
      ${link(item.booking_url, "Booking page")} ${link(item.source_url, "Evidence")}`;
  } else if (kind === "stay") {
    details = `<p>${escapeHtml(item.type || "Accommodation")}</p><p class="amount">Per night: ${money(item.estimated_price_per_night_inr)}</p>
      ${item.notes ? `<p>${escapeHtml(item.notes)}</p>` : ""}${link(item.booking_url, "Booking page")} ${link(item.source_url, "Evidence")}`;
  } else {
    details = `<p>${escapeHtml(item.description || "")}</p><p class="amount">Estimated cost: ${money(item.estimated_cost_inr)}</p>${link(item.source_url, "Source")}`;
  }
  return `<div class="result-item"><strong>${escapeHtml(name)}</strong>${details}</div>`;
}
function renderStructured(data, trip, disclaimer) {
  const transport = Array.isArray(data.transport_options) ? data.transport_options : [];
  const stays = Array.isArray(data.stay_options) ? data.stay_options : [];
  const places = Array.isArray(data.places_to_visit) ? data.places_to_visit : [];
  const sources = Array.isArray(data.sources) ? data.sources : [];
  const budget = data.estimated_budget_inr || {};
  const summary = data.trip_summary || `Trip research for ${trip.origin} to ${trip.destination}`;
  const meta = [
    `${trip.origin} → ${trip.destination}`,
    trip.date,
    `${trip.travellers} traveller(s)`,
    `${trip.budget} plan`
  ].map(v => `<span class="chip">${escapeHtml(v)}</span>`).join("");
  resultsBox.innerHTML = `
    <div class="result-head"><div class="eyebrow">YOUR RESEARCH BRIEF</div><h2>${escapeHtml(summary)}</h2>
      <p>Research compiled from the web. Follow the source links to verify details before booking.</p><div class="result-meta">${meta}</div></div>
    <div class="result-grid">
      <section class="result-card"><h3>01 · Transport options</h3>${transport.length ? transport.map(x => itemCard(x, "transport")).join("") : "<p>No verified transport options returned.</p>"}</section>
      <section class="result-card"><h3>02 · Stay options</h3>${stays.length ? stays.map(x => itemCard(x, "stay")).join("") : "<p>No verified stay options returned.</p>"}</section>
      <section class="result-card"><h3>03 · Places to visit</h3>${places.length ? places.map(x => itemCard(x, "place")).join("") : "<p>No destination activities returned.</p>"}</section>
      <section class="result-card"><h3>04 · Estimated budget</h3>
        <div class="result-item"><p>Transport</p><strong>${money(budget.transport_total)}</strong></div>
        <div class="result-item"><p>Stay</p><strong>${money(budget.stay_total)}</strong></div>
        <div class="result-item"><p>Activities</p><strong>${money(budget.activities_total)}</strong></div>
        <div class="budget-total"><p>Overall estimate</p><strong>${money(budget.overall_total)}</strong>${budget.assumptions ? `<p>${escapeHtml(budget.assumptions)}</p>` : ""}</div>
      </section>
    </div>
    ${Array.isArray(data.important_notes) && data.important_notes.length ? `<section class="result-card" style="margin-top:14px"><h3>Important notes</h3><ul>${data.important_notes.map(n => `<li>${escapeHtml(n)}</li>`).join("")}</ul></section>` : ""}
    ${sources.length ? `<section class="result-card" style="margin-top:14px"><h3>Sources checked</h3><ul class="source-list">${sources.map(s => `<li>${link(s.url, s.title || s.url) || escapeHtml(s.title || s.url)}</li>`).join("")}</ul></section>` : ""}
    <div class="disclaimer">${escapeHtml(disclaimer || "Fares, schedules and room availability may change. Verify with the provider before payment.")}</div>`;
  resultsBox.classList.remove("hidden");
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  resultsBox.classList.add("hidden");
  const formData = new FormData(form);
  const payload = Object.fromEntries(formData.entries());
  payload.travellers = Number(payload.travellers);
  submitBtn.disabled = true;
  submitBtn.innerHTML = "<span>Researching live websites…</span><span class='spinner'>↻</span>";
  showStatus("TinyFish is researching public web sources. This can take up to a few minutes; please keep this tab open.", "loading");
  try {
    const response = await fetch("/api/research", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "Research failed.");
    if (data.result && typeof data.result === "object") {
      renderStructured(data.result, payload, data.disclaimer);
      showStatus(`Research completed. TinyFish returned ${data.eventCount} event(s). Check each source link before booking.`);
    } else {
      resultsBox.innerHTML = `<div class="result-head"><div class="eyebrow">RESEARCH OUTPUT</div><h2>Research completed</h2><p>The agent responded, but its output did not parse as the requested JSON. Review the raw response below.</p></div><pre class="raw-output">${escapeHtml(data.rawSummary || "No text result returned.")}</pre><div class="disclaimer">${escapeHtml(data.disclaimer || "")}</div>`;
      resultsBox.classList.remove("hidden");
      showStatus("TinyFish completed the run, but the response format needs a small adjustment. The raw response is available below.", "loading");
    }
  } catch (error) {
    showStatus(`${error.message} Check that the server is running, the TinyFish key is configured in .env, and then retry.`, "error");
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = "<span>Research my trip</span><span aria-hidden='true'>→</span>";
  }
});
