require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const TINYFISH_API_KEY = process.env.TINYFISH_API_KEY;
const TINYFISH_AGENT_URL = "https://agent.tinyfish.ai/v1/automation/run-sse";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: true, legacyHeaders: false }));

function cleanText(value, max = 120) {
  return String(value || "").trim().slice(0, max);
}

function parseSseEvents(raw) {
  const events = [];
  const blocks = raw.split(/\r?\n\r?\n/);
  for (const block of blocks) {
    const dataLines = block.split(/\r?\n/)
      .filter(line => line.startsWith("data:"))
      .map(line => line.slice(5).trim());
    if (!dataLines.length) continue;
    const data = dataLines.join("\n");
    if (!data || data === "[DONE]") continue;
    try { events.push(JSON.parse(data)); }
    catch { events.push({ message: data }); }
  }
  return events;
}

function flattenEventText(value, depth = 0) {
  if (depth > 5 || value == null) return "";
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return value.map(v => flattenEventText(v, depth + 1)).filter(Boolean).join("\n");
  if (typeof value === "object") {
    const preferred = ["result", "output", "content", "text", "message", "response", "data"];
    const parts = [];
    for (const key of preferred) {
      if (value[key] !== undefined) {
        const text = flattenEventText(value[key], depth + 1);
        if (text) parts.push(text);
      }
    }
    return parts.join("\n") || "";
  }
  return String(value);
}

function tryExtractJson(text) {
  if (!text) return null;
  const cleaned = text.replace(/```(?:json)?/gi, "").trim();
  try { return JSON.parse(cleaned); } catch {}
  const firstObj = cleaned.indexOf("{");
  const lastObj = cleaned.lastIndexOf("}");
  if (firstObj >= 0 && lastObj > firstObj) {
    try { return JSON.parse(cleaned.slice(firstObj, lastObj + 1)); } catch {}
  }
  const firstArr = cleaned.indexOf("[");
  const lastArr = cleaned.lastIndexOf("]");
  if (firstArr >= 0 && lastArr > firstArr) {
    try { return JSON.parse(cleaned.slice(firstArr, lastArr + 1)); } catch {}
  }
  return null;
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, tinyfishConfigured: Boolean(TINYFISH_API_KEY) });
});

app.post("/api/research", async (req, res) => {
  if (!TINYFISH_API_KEY) {
    return res.status(503).json({
      error: "TinyFish API key is not configured.",
      hint: "Copy .env.example to .env, add TINYFISH_API_KEY, and restart the server."
    });
  }

  const origin = cleanText(req.body.origin, 80);
  const destination = cleanText(req.body.destination, 80);
  const date = cleanText(req.body.date, 20);
  const travellers = Math.max(1, Math.min(12, Number.parseInt(req.body.travellers, 10) || 1));
  const budget = cleanText(req.body.budget, 20);
  const tripType = cleanText(req.body.tripType || "general", 30);
  const notes = cleanText(req.body.notes, 240);

  if (!origin || !destination || !date || !budget) {
    return res.status(400).json({ error: "Origin, destination, travel date and budget are required." });
  }
  if (origin.toLowerCase() === destination.toLowerCase()) {
    return res.status(400).json({ error: "Origin and destination must be different." });
  }
  if (!["affordable", "moderate", "premium"].includes(budget)) {
    return res.status(400).json({ error: "Choose affordable, moderate or premium." });
  }

  const searchQuery = encodeURIComponent(`${origin} to ${destination} travel transport hotel tourist places ${date}`);
  const startUrl = `https://www.google.com/search?q=${searchQuery}`;

  const goal = `
You are the live-web research agent for JanYatri, an Indian travel-planning prototype.
Research this trip using publicly accessible web pages:
Origin: ${origin}
Destination: ${destination}
Travel date: ${date}
Travellers: ${travellers}
Budget tier: ${budget}
Trip type: ${tripType}
Additional preferences: ${notes || "None"}

Use live web research. Prefer official transport operators, official tourism sites and reputable booking pages.
Find practical transport options and approximate fares when visible, possible travel duration, 2-5 destination activities/places, stay suggestions if relevant, and source URLs.
Do not invent prices, availability, booking confirmations, or URLs. If a fare or detail cannot be verified, use null and explain it.
Treat displayed prices as estimates unless the source clearly states otherwise. State currency as INR.
Recommend options matching the selected budget tier:
- affordable: prioritize lower-cost public transport, budget stays, and free/low-cost attractions
- moderate: balance cost and comfort
- premium: prioritize comfort and convenience
For each item include a source URL. Return ONLY valid JSON with this structure:
{
  "trip_summary": "short summary",
  "route": {"origin":"...", "destination":"...", "travel_date":"...", "travellers": ${travellers}},
  "budget_tier": "${budget}",
  "transport_options": [
    {"mode":"...", "operator":"...", "estimated_fare_inr": null, "duration":"...", "departure_or_schedule":"...", "booking_url":"...", "source_url":"...", "notes":"..."}
  ],
  "stay_options": [
    {"name":"...", "estimated_price_per_night_inr": null, "type":"...", "booking_url":"...", "source_url":"...", "notes":"..."}
  ],
  "places_to_visit": [
    {"name":"...", "estimated_cost_inr": null, "description":"...", "source_url":"..."}
  ],
  "estimated_budget_inr": {"transport_total": null, "stay_total": null, "activities_total": null, "overall_total": null, "assumptions":"..."},
  "important_notes": ["..."],
  "sources": [{"title":"...", "url":"..."}]
}
Return only findings supported by the pages you actually inspect. If exact-date availability is not shown, say so.
`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 180_000);

  try {
    const upstream = await fetch(TINYFISH_AGENT_URL, {
      method: "POST",
      headers: {
        "X-API-Key": TINYFISH_API_KEY,
        "Content-Type": "application/json",
        "Accept": "text/event-stream"
      },
      body: JSON.stringify({ url: startUrl, goal }),
      signal: controller.signal
    });

    const raw = await upstream.text();
    if (!upstream.ok) {
      console.error("TinyFish upstream error:", upstream.status, raw.slice(0, 1200));
      return res.status(502).json({
        error: "TinyFish could not complete the research request.",
        upstreamStatus: upstream.status,
        hint: upstream.status === 401 || upstream.status === 403
          ? "Check whether the TinyFish API key is valid and enabled."
          : "Check the server terminal for the upstream error, then retry."
      });
    }

    const events = parseSseEvents(raw);
    const eventText = events.map(e => flattenEventText(e)).filter(Boolean).join("\n");
    const jsonResult = tryExtractJson(eventText);

    return res.json({
      ok: true,
      provider: "TinyFish",
      trip: { origin, destination, date, travellers, budget, tripType },
      result: jsonResult,
      rawSummary: jsonResult ? null : (eventText || raw).slice(0, 16000),
      eventCount: events.length,
      disclaimer: "Research results are estimates, not booking confirmations. Verify fares, availability and terms with the source before payment."
    });
  } catch (error) {
    const timedOut = error.name === "AbortError";
    console.error("JanYatri research error:", error.message);
    return res.status(timedOut ? 504 : 500).json({
      error: timedOut ? "TinyFish research timed out. Try a simpler trip or retry." : "Research failed unexpectedly.",
      hint: "Confirm the server is running and the TinyFish API key is configured."
    });
  } finally {
    clearTimeout(timeout);
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`JanYatri TinyFish agent running at http://localhost:${PORT}`);
  console.log(`TinyFish key configured: ${Boolean(TINYFISH_API_KEY)}`);
});
